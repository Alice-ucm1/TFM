<?php
//Conexion a la base de datos
$con = mysqli_connect("localhost", "root", "", "bd_sport") or die("Error " . mysqli_error($con));
?>